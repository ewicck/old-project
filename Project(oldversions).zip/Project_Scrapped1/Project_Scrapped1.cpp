/* 
 * File:   Project_Scrapped1
 * Author: i missed you
 * Created on June 9, 2023, 10:35 PM
 */

#include <iostream>
#include <cstdlib>
#include <ctime>
#include <string>
#include <vector>
#include <algorithm>
#include <random>

using namespace std;

// Card class
class Card {
public:
    int value;
    string suit;

    Card(int value, string suit): value(value), suit(suit) {}
};

// Deck class
class Deck {
public:
    vector<Card> cards;

    Deck() {
        string suits[4] = {"Hearts", "Diamonds", "Clubs", "Spades"};
        for (string suit : suits) {
            for (int value = 1; value <= 13; ++value) {
                cards.push_back(Card(value > 10 ? 10 : value, suit));
            }
        }
    }

    void shuffleDeck() {
        auto rng = default_random_engine{};
        std::shuffle(std::begin(cards), std::end(cards), rng);
    }

    Card drawCard() {
        Card drawnCard = cards.back();
        cards.pop_back();
        return drawnCard;
    }
};

// Function prototypes
void playerTurn(string playerName, int &playerTotal, Deck &deck, int blackjack);
void checkBlackjack(string playerName, int playerTotal, bool &playerBlackjack, int blackjack);
void calculateBet(string playerName, float &playerMoney, float &playerBet);
void determineWinner(int playerTotals[], string playerNames[], float playerMoney[], float playerBets[], int numberOfPlayers, int blackjack);
void printFinalResults(int playerTotals[], string playerNames[], float playerMoney[], int numberOfPlayers, int blackjack);
void printCard(Card &card);

// New function prototypes
void checkBust(string playerName, int &playerTotal, int blackjack);
void drawCard(string playerName, int &playerTotal, Deck &deck);
void passTurn(string playerName);
void quitGame(string playerName, int &playerTotal);

int main() {
    // Constants
    const int NUMBER_OF_PLAYERS = 3;
    const int NUMBER_OF_ROUNDS = 3;
    const int AI_DRAW_LIMIT = 17;
    const int BLACKJACK = 21;
    const int INITIAL_MONEY = 100;

    // Initialize player totals, player money, player bets, player names
    int playerTotals[NUMBER_OF_PLAYERS] = {0};
    float playerMoney[NUMBER_OF_PLAYERS] = {INITIAL_MONEY, INITIAL_MONEY, INITIAL_MONEY};
    float playerBets[NUMBER_OF_PLAYERS] = {0};
    string playerNames[NUMBER_OF_PLAYERS] = {"", "Opponent 1", "Opponent 2"};

    // Initialize two-dimensional array to store player scores
    int playerScores[NUMBER_OF_PLAYERS][NUMBER_OF_ROUNDS] = {0};

    // Initialize current round
    int currentRound = 0;

    // Player specific variables
    bool playerBlackjack = false;

    // Create and shuffle deck
    Deck deck;
    deck.shuffleDeck();

    // Get player name
    cout << "Enter your name: ";
    cin >> playerNames[0];

    // Initial draw for all players
    for (int i = 0; i < NUMBER_OF_PLAYERS; ++i) {
        playerTotals[i] = deck.drawCard().value;
        playerTotals[i] += deck.drawCard().value;
    }

    // Check if player got a blackjack in the initial draw
    checkBlackjack(playerNames[0], playerTotals[0], playerBlackjack, BLACKJACK);

    // If the player didn't get a blackjack, let them play
    if (!playerBlackjack) {
        calculateBet(playerNames[0], playerMoney[0], playerBets[0]);
        playerTurn(playerNames[0], playerTotals[0], deck, BLACKJACK);
    }

    // If player hasn't quit, then opponents play
    if (playerTotals[0] != -1) {
        // Opponent's turn
        for (int i = 1; i < NUMBER_OF_PLAYERS; ++i) {
            while (playerTotals[i] < AI_DRAW_LIMIT && playerTotals[i] <= BLACKJACK) {
                playerTotals[i] += deck.drawCard().value;
            }
        }
    }

    // After determining the winner in each round
    determineWinner(playerTotals, playerNames, playerMoney, playerBets, NUMBER_OF_PLAYERS, BLACKJACK);

    // Store player totals for the current round
    for (int i = 0; i < NUMBER_OF_PLAYERS; ++i) {
        playerScores[i][currentRound] = playerTotals[i];
    }

    // Print final results of the round
    printFinalResults(playerTotals, playerNames, playerMoney, NUMBER_OF_PLAYERS, BLACKJACK);

    cout << "\nThank you for playing, " << playerNames[0] << "!\n";

    return 0;
}

void playerTurn(string playerName, int &playerTotal, Deck &deck, int blackjack) {
    int choice;
    bool quit = false;

    while (!quit && playerTotal <= blackjack) {
        cout << playerName << ", your total is " << playerTotal << ".\n";
        cout << "Enter 1 to draw a card, 2 to pass, or 0 to quit: ";
        cin >> choice;

        switch (choice) {
            case 1:
                drawCard(playerName, playerTotal, deck);
                break;

            case 2:
                passTurn(playerName);
                quit = true;
                break;

            case 0:
                quitGame(playerName, playerTotal);
                quit = true;
                break;

            default:
                cout << "Invalid choice! Please try again.\n";
                break;
        }

        checkBust(playerName, playerTotal, blackjack);
    }
}

void checkBlackjack(string playerName, int playerTotal, bool &playerBlackjack, int blackjack) {
    if (playerTotal == blackjack) {
        cout << playerName << ", you got a Blackjack!\n";
        playerBlackjack = true;
    }
}

void calculateBet(string playerName, float &playerMoney, float &playerBet) {
    do {
        cout << playerName << ", you have $" << playerMoney << ". How much would you like to bet? ";
        cin >> playerBet;

        if (playerBet > playerMoney) {
            cout << "You cannot bet more money than you have. Try again.\n";
        }
    } while (playerBet > playerMoney);

    playerMoney -= playerBet; // Deduct bet from player's money
}

void determineWinner(int playerTotals[], string playerNames[], float playerMoney[], float playerBets[], int numberOfPlayers, int blackjack) {
    int highestTotal = 0;
    int winnerIndex = -1;

    for (int i = 0; i < numberOfPlayers; ++i) {
        if (playerTotals[i] > highestTotal && playerTotals[i] <= blackjack) {
            highestTotal = playerTotals[i];
            winnerIndex = i;
        }
    }

    if (winnerIndex != -1) {
        playerMoney[winnerIndex] += 2 * playerBets[winnerIndex];
    }
}

void printFinalResults(int playerTotals[], string playerNames[], float playerMoney[], int numberOfPlayers, int blackjack) {
    for (int i = 0; i < numberOfPlayers; ++i) {
        cout << playerNames[i] << "'s total is " << playerTotals[i] << ". ";
        cout << playerNames[i] << " now has $" << playerMoney[i] << ".\n";
    }
}

void printCard(Card &card) {
    string valueName;
    if (card.value == 1) {
        valueName = "Ace";
    } else if (card.value == 11) {
        valueName = "Jack";
    } else if (card.value == 12) {
        valueName = "Queen";
    } else if (card.value == 13) {
        valueName = "King";
    } else {
        valueName = to_string(card.value);
    }

    cout << valueName << " of " << card.suit << "\n";
}

// New function definitions
void checkBust(string playerName, int &playerTotal, int blackjack) {
    if (playerTotal > blackjack) {
        cout << playerName << " busts!\n";
        playerTotal = 0;
    }
}

void drawCard(string playerName, int &playerTotal, Deck &deck) {
    Card drawnCard = deck.drawCard();
    playerTotal += drawnCard.value;
    printCard(drawnCard);
}

void passTurn(string playerName) {
    cout << playerName << " passes their turn.\n";
}

void quitGame(string playerName, int &playerTotal) {
    cout << playerName << " has quit the game.\n";
    playerTotal = -1;
}